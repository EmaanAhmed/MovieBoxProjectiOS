//
//  Review.swift
//  MovieBoxFinal
//
//  Created by 2unni on 3/13/20.
//  Copyright © 2020 2unni. All rights reserved.
//

import Foundation
class Review
{
    var author : String?
    var content : String?
    
    init(author: String,content: String)
    {
        self.author = author
        self.content = content
    }
}
