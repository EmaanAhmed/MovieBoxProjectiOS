//
//  MyReviewsTableViewCell.swift
//  MovieBoxFinal
//
//  Created by 2unni on 3/13/20.
//  Copyright © 2020 2unni. All rights reserved.
//

import UIKit

class MyReviewsTableViewCell : UITableViewCell{
    

    @IBOutlet weak var myAuthor: UILabel!
    
    @IBOutlet weak var myContent: UILabel!
}
