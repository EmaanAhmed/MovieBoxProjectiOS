//
//  ViewController.swift
//  MovieBoxFinal
//
//  Created by 2unni on 2/29/20.
//  Copyright © 2020 2unni. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

