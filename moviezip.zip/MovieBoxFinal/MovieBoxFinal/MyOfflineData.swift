//
//  MyOfflineData.swift
//  MovieBoxFinal
//
//  Created by 2unni on 3/15/20.
//  Copyright © 2020 2unni. All rights reserved.
//

import Foundation
import CoreData
import SDWebImage



class MyOfflineData
{
    var appdeleget : AppDelegate?
    var nsContext : NSManagedObjectContext?
    init(appdeleget : AppDelegate){
        self.appdeleget = appdeleget
        nsContext = appdeleget.persistentContainer.viewContext
    }

    func AddMovie(movie : Movie)
    {
        let entity = NSEntityDescription.insertNewObject(forEntityName: "Favorits", into:nsContext! )
        entity.setValue(movie.title, forKey: "title")
        entity.setValue(movie.vote_average, forKey: "vote_average")
        entity.setValue(movie.poster_path, forKey: "poster_path")
        do{
            try self.nsContext?.save()
        }
        catch
        {
            
        }
        
    }
    func getFavorites()->[Any]
    {
        var movies : [Any] = []
        var myMovies = [Favorits]()
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Favorits")
        myMovies = try!nsContext!.fetch(fetchRequest) as![Favorits]
        for movie in myMovies
        {
            movies.append(movie)
        }
        return movies
    }
}
