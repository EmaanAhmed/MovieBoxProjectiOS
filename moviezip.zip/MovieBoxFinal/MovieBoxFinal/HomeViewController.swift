//
//  HomeViewController.swift
//  MovieBoxFinal
//
//  Created by 2unni on 2/29/20.
//  Copyright © 2020 2unni. All rights reserved.
//

import UIKit
import SDWebImage
import SwiftyJSON
import YouTubePlayer

class HomeViewController: UIViewController ,UICollectionViewDelegate,UICollectionViewDataSource,ReloadDataDeleget,ReloadVideoURLDeleget{
    func reloadVideoURL(key: String) {
        myPlayer.isHidden = false
        myPlayer.loadVideoID(key)
    }
    
    @IBAction func watch(_ sender: Any) {
        myVideo = Video(id:movieList![6].id!,deleget: self)
        myVideo.getURL()
    }
    

    @IBOutlet weak var myLbl: UILabel!
    @IBOutlet weak var mySegmat: UISegmentedControl!
    @IBOutlet weak var myBigImageView: UIImageView!
    private var networkingClient : NetworkClient!
    @IBOutlet weak var myPlayer: YouTubePlayerView!
    var movieList : [Movie]?
    @IBOutlet weak var myCollectionView: UICollectionView!
    let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
    var screenSize: CGRect!
    var screenWidth: CGFloat!
    var screenHeight: CGFloat!
    var detailsView = DetailsViewController()
    
    

    private var myVideo :  Video!
    override func viewDidLoad() {
        super.viewDidLoad()
        detailsView = self.storyboard?.instantiateViewController(withIdentifier: "detailsView") as! DetailsViewController

        
        screenSize = UIScreen.main.bounds
               screenWidth = screenSize.width
               screenHeight = screenSize.height
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 10, right: 0)
              layout.itemSize = CGSize(width: screenWidth/4, height: screenWidth/3)
              layout.minimumInteritemSpacing = 0
              layout.minimumLineSpacing = 10
              myCollectionView.collectionViewLayout = layout

        guard let urtToExecute = URL(string: "https://api.themoviedb.org/3/discover/movie?api_key=d048bec4f5e8f1dda36816ab99be899e&language=en-US&sort_by=popularity.desc") else {
            return
        }
        networkingClient = NetworkClient(url: urtToExecute,deleget: self)
        movieList = networkingClient?.execute()


    }

  
    func reloadMovies(_movies: [Movie]) {
        movieList = _movies
        self.myCollectionView.reloadData()
        myPlayer.isHidden = true
        myBigImageView.sd_setImage(with: URL(string: movieList![6].backdrop_path!), placeholderImage:nil)
        myLbl.text = movieList![6].title!
    }
    
    @IBAction func valueChanged(_ sender: Any) {
        
        switch mySegmat.selectedSegmentIndex {
        case 0:
            guard let urtToExecute = URL(string: "https://api.themoviedb.org/3/discover/movie?api_key=d048bec4f5e8f1dda36816ab99be899e&language=en-US&sort_by=popularity.desc") else {
                return
            }
            networkingClient = NetworkClient(url: urtToExecute,deleget: self)
            movieList = networkingClient?.execute()
            
        case 1:
            guard let urtToExecute = URL(string: "https://api.themoviedb.org/3/discover/movie/?api_key=d048bec4f5e8f1dda36816ab99be899e&certification_country=US&certification=R&sort_by=vote_average.desc") else {
                return
            }
            networkingClient = NetworkClient(url: urtToExecute,deleget: self)
            movieList = networkingClient?.execute()
            
        default:
            break
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        myPlayer.isHidden = true
        
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        
        return movieList!.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! MyCollectionViewCell
        cell.myImg!.sd_setImage(with: URL(string: movieList![indexPath.row].poster_path!), placeholderImage:UIImage(named: "myPlaceHolder"))

        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        detailsView.imgpath = movieList![indexPath.row].poster_path
        detailsView.orgtitle = movieList![indexPath.row].original_title
        detailsView.rate = movieList![indexPath.row].vote_average
        detailsView.date = movieList![indexPath.row].release_date
        detailsView.overview = movieList![indexPath.row].overview
        detailsView.id = movieList![indexPath.row].id
        self.present(detailsView, animated: true, completion: nil)

    }
    
    
    @IBOutlet weak var favBtn: UIButton!
    @IBAction func favClicked(_ sender: Any) {
        if(favBtn.currentImage == UIImage(named: "fill"))
        {
            favBtn.setImage(UIImage(named: "empty"), for: .normal)
            
        }
        else
        {
            favBtn.setImage(UIImage(named: "fill"), for: .normal)
        }
        
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
