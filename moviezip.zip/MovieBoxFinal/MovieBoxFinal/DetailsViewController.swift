//
//  DetailsViewController.swift
//  MovieBoxFinal
//
//  Created by 2unni on 3/13/20.
//  Copyright © 2020 2unni. All rights reserved.
//

import UIKit
import Cosmos
import SDWebImage
import YouTubePlayer

class DetailsViewController: UIViewController,ReloadVideoURLDeleget{

    

    @IBOutlet weak var myImg: UIImageView!
    @IBOutlet weak var myTitle: UILabel!
    @IBOutlet weak var starsView: CosmosView!
    @IBOutlet weak var myDate: UILabel!
    @IBOutlet weak var myOverView: UILabel!
    @IBOutlet weak var myPlayer: YouTubePlayerView!

    var imgpath : String?
    var orgtitle : String?
    var rate : Double?
    var date : String?
    var overview : String?
    var id: Int?
    

    
    private var myVideo :  Video!
    var reviewsView = ReviewsTableViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        reviewsView = self.storyboard?.instantiateViewController(withIdentifier: "reviewsView") as! ReviewsTableViewController
        

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        myImg.sd_setImage(with: URL(string: imgpath!), placeholderImage:UIImage(named: "myPlaceHolder"))
        myTitle.text = orgtitle
        starsView.settings.updateOnTouch = false
        starsView.settings.fillMode = .precise
        starsView.rating = rate!/2
        myDate.text = date
        myOverView.text = overview
        myPlayer.isHidden = true
    }
    
    @IBAction func backAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func watchAction(_ sender: Any) {
        print(id)
        myVideo = Video(id:id!,deleget: self)
        myVideo.getURL()
        
    }
    
    func reloadVideoURL(key: String) {
        myPlayer.isHidden = false
        myPlayer.loadVideoID(key)
    }
    
    @IBAction func tapAction(_ sender: Any) {
        myPlayer.isHidden = true
    }
    
    @IBAction func checkReviews(_ sender: Any) {
        reviewsView.id = id
        self.present(reviewsView, animated: true, completion: nil)
 
    }
    
    
    @IBOutlet weak var favBtn: UIButton!
    @IBAction func favCkicked(_ sender: Any) {
//        if(favBtn.currentImage == UIImage(named: "fill"))
//        {
//            favBtn.setImage(UIImage(named: "empty"), for: .normal)
//        }
//        else
//        {
            favBtn.setImage(UIImage(named: "fill"), for: .normal)
            var coredata = MyOfflineData(appdeleget: UIApplication.shared.delegate as! AppDelegate)
            var movie = Movie(title: orgtitle!, poster: imgpath!, rate: rate!)
            coredata.AddMovie(movie: movie)
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
