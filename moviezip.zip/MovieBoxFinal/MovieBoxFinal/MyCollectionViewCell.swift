//
//  MyCollectionViewCell.swift
//  MovieBoxFinal
//
//  Created by 2unni on 2/29/20.
//  Copyright © 2020 2unni. All rights reserved.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var myImg: UIImageView!
    
}
