//
//  Favorits+CoreDataClass.swift
//  
//
//  Created by 2unni on 3/15/20.
//
//

import Foundation
import CoreData

@objc(Favorits)
public class Favorits: NSManagedObject {

}
